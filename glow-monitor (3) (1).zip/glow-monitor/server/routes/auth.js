const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const mongoose = require('mongoose');
const User = require('../models/User');

const router = express.Router();

function issueToken(user) {
  return jwt.sign(
    { userId: user._id.toString(), shortName: user.shortName },
    process.env.JWT_SECRET,
    { expiresIn: '7d' }
  );
}

function publicUser(user) {
  return {
    id: user._id,
    fullName: user.fullName,
    shortName: user.shortName,
    email: user.email,
    reminderPreferences: user.reminderPreferences,
  };
}

// POST /api/auth/signup
router.post('/signup', async (req, res) => {
  try {
    const { fullName, shortName, email, password } = req.body;

    // Validate input before touching the database at all — a malformed
    // request should get a fast, accurate 400 regardless of DB health.
    if (!fullName || !shortName || !email || typeof password !== 'string') {
      return res.status(400).json({ error: 'Full name, short name, email and password are all required.' });
    }
    if (password.length < 8) {
      return res.status(400).json({ error: 'Password must be at least 8 characters.' });
    }
    if (mongoose.connection.readyState !== 1) {
      return res.status(503).json({ error: 'The database is temporarily unavailable. Please try again in a moment.' });
    }

    const normalizedEmail = String(email).toLowerCase().trim();
    const existing = await User.findOne({ email: normalizedEmail });
    if (existing) {
      return res.status(409).json({ error: 'An account with this email already exists — try logging in instead.' });
    }

    const passwordHash = await bcrypt.hash(password, 12);
    const user = await User.create({
      fullName: String(fullName).trim(),
      shortName: String(shortName).trim(),
      email: normalizedEmail,
      passwordHash,
    });

    const token = issueToken(user);
    res.status(201).json({ token, user: publicUser(user) });
  } catch (err) {
    // BUG FIX: findOne-then-create isn't atomic — two concurrent signups
    // with the same email can both pass the findOne check and race to
    // create(), so MongoDB's unique index throws a duplicate-key error
    // (code 11000) here instead. That was falling through to a generic,
    // confusing 500; it's now reported the same way as the normal
    // pre-check above.
    if (err.code === 11000) {
      return res.status(409).json({ error: 'An account with this email already exists — try logging in instead.' });
    }
    // BUG FIX: Mongoose schema validation errors (e.g. name too long,
    // malformed email) were also falling through to a generic 500 instead
    // of a helpful 400 with the actual validation message.
    if (err.name === 'ValidationError') {
      const firstMessage = Object.values(err.errors)[0]?.message || 'Invalid input.';
      return res.status(400).json({ error: firstMessage });
    }
    console.error('Signup error:', err);
    res.status(500).json({ error: 'Something went wrong creating your account. Please try again.' });
  }
});

// POST /api/auth/login
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || typeof password !== 'string') {
      return res.status(400).json({ error: 'Email and password are required.' });
    }
    if (mongoose.connection.readyState !== 1) {
      return res.status(503).json({ error: 'The database is temporarily unavailable. Please try again in a moment.' });
    }

    const user = await User.findOne({ email: String(email).toLowerCase().trim() });
    if (!user) {
      return res.status(401).json({ error: 'Invalid email or password.' });
    }

    const match = await bcrypt.compare(password, user.passwordHash);
    if (!match) {
      return res.status(401).json({ error: 'Invalid email or password.' });
    }

    const token = issueToken(user);
    res.json({ token, user: publicUser(user) });
  } catch (err) {
    console.error('Login error:', err);
    res.status(500).json({ error: 'Something went wrong logging in. Please try again.' });
  }
});

module.exports = router;
