const express = require('express');
const mongoose = require('mongoose');
const LiveLog = require('../models/LiveLog');
const User = require('../models/User');
const { verifyToken } = require('../middleware/auth');
const { requireDb } = require('../middleware/db');

const router = express.Router();

// GET /api/live/current — latest reading per metric, for first paint before
// the socket connection delivers the next live tick.
router.get('/current', verifyToken, requireDb, async (req, res) => {
  try {
    const recent = await LiveLog.find().sort({ timestamp: -1 }).limit(50);
    const latestByMetric = {};
    for (const log of recent) {
      if (!latestByMetric[log.metricType]) latestByMetric[log.metricType] = log;
    }
    res.json(Object.values(latestByMetric));
  } catch (err) {
    console.error('Fetch current live data error:', err);
    res.status(500).json({ error: 'Could not load live data.' });
  }
});

// GET /api/live/history?metric=uv&hours=24 — for charting/trend views
router.get('/history', verifyToken, async (req, res) => {
  try {
    const { metric, hours } = req.query;
    if (!metric) return res.status(400).json({ error: 'metric query param is required.' });

    // BUG FIX: Number(hours) on a bad/missing value (e.g. "abc", "", or an
    // absurd number) produced NaN, which propagated into `new Date(NaN)`
    // ("Invalid Date") and was passed straight into the Mongo query,
    // silently returning wrong/empty results instead of a clear error.
    // Now it's validated and clamped to a sane range (1 hour – 30 days).
    const parsedHours = Number(hours);
    if (hours !== undefined && !Number.isFinite(parsedHours)) {
      return res.status(400).json({ error: 'hours must be a positive number.' });
    }
    const boundedHours = Number.isFinite(parsedHours) && parsedHours > 0
      ? Math.min(parsedHours, 24 * 30)
      : 24;

    if (mongoose.connection.readyState !== 1) {
      return res.status(503).json({ error: 'The database is temporarily unavailable. Please try again in a moment.' });
    }

    const since = new Date(Date.now() - boundedHours * 60 * 60 * 1000);
    const logs = await LiveLog.find({ metricType: metric, timestamp: { $gte: since } })
      .sort({ timestamp: 1 })
      .limit(1000);
    res.json(logs);
  } catch (err) {
    console.error('Fetch live history error:', err);
    res.status(500).json({ error: 'Could not load history.' });
  }
});

// PATCH /api/live/reminder-preferences — user tunes their own thresholds/times
router.patch('/reminder-preferences', verifyToken, requireDb, async (req, res) => {
  try {
    const { morningRoutineTime, eveningRoutineTime, uvAlertThreshold, tankLowThreshold } = req.body;
    const update = {};
    if (morningRoutineTime) update['reminderPreferences.morningRoutineTime'] = morningRoutineTime;
    if (eveningRoutineTime) update['reminderPreferences.eveningRoutineTime'] = eveningRoutineTime;
    if (typeof uvAlertThreshold === 'number') update['reminderPreferences.uvAlertThreshold'] = uvAlertThreshold;
    if (typeof tankLowThreshold === 'number') update['reminderPreferences.tankLowThreshold'] = tankLowThreshold;

    const user = await User.findByIdAndUpdate(req.user.userId, { $set: update }, { new: true });
    if (!user) return res.status(404).json({ error: 'User not found.' });
    res.json({ reminderPreferences: user.reminderPreferences });
  } catch (err) {
    console.error('Update reminder preferences error:', err);
    res.status(500).json({ error: 'Could not update preferences.' });
  }
});

module.exports = router;
