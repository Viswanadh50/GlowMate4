const mongoose = require('mongoose');

/**
 * LiveLog schema
 * Generic, scalable structure for ANY "live level" metric — UV index,
 * air quality, water tank level, humidity, whatever the deployment needs.
 * Add a new metricType string and a matching entry in sockets/liveData.js's
 * METRICS array; no schema change required.
 */
const liveLogSchema = new mongoose.Schema({
  metricType: { type: String, required: true, index: true }, // e.g. 'uv', 'tankLevel', 'airQuality'
  label: { type: String, required: true },                    // human-readable name
  value: { type: Number, required: true },
  unit: { type: String, default: '' },
  location: {
    lat: Number,
    lng: Number,
    label: String,
  },
  timestamp: { type: Date, default: Date.now },
});

// Keep the collection from growing forever in a demo/dev environment —
// auto-expire raw readings after 30 days. Remove this if you need longer
// historical retention, and aggregate into a rollup collection instead.
liveLogSchema.index({ timestamp: 1 }, { expireAfterSeconds: 60 * 60 * 24 * 30 });

module.exports = mongoose.model('LiveLog', liveLogSchema);
