const mongoose = require('mongoose');

/**
 * User schema
 * - fullName / shortName kept separate so the dashboard can greet with the
 *   short name ("Good morning, Vishwa") while full name is used for account
 *   and formal contexts.
 * - passwordHash only — plaintext passwords are never stored.
 * - location is optional and is used as the default center point for the
 *   live map until the browser's geolocation overrides it client-side.
 */
const userSchema = new mongoose.Schema(
  {
    fullName: { type: String, required: true, trim: true, maxlength: 120 },
    shortName: { type: String, required: true, trim: true, maxlength: 40 },
    email: {
      type: String,
      required: true,
      unique: true,
      lowercase: true,
      trim: true,
      match: [/^\S+@\S+\.\S+$/, 'Enter a valid email address'],
    },
    passwordHash: { type: String, required: true },
    location: {
      lat: { type: Number, default: null },
      lng: { type: Number, default: null },
      label: { type: String, default: null },
    },
    // Per-user reminder preferences — lets each user tune thresholds/times
    // without touching server code. See routes/live.js for usage.
    reminderPreferences: {
      morningRoutineTime: { type: String, default: '07:30' }, // "HH:MM" 24h
      eveningRoutineTime: { type: String, default: '21:30' },
      uvAlertThreshold: { type: Number, default: 6 },
      tankLowThreshold: { type: Number, default: 20 },
    },
  },
  { timestamps: true }
);

module.exports = mongoose.model('User', userSchema);
