const mongoose = require('mongoose');

/**
 * Mongoose buffers queries while disconnected rather than rejecting them
 * immediately, which means a route can hang for the full serverSelection
 * timeout during an outage instead of failing fast. Routes that read/write
 * the database call this first so users get an immediate, honest
 * "temporarily unavailable" response instead of a frozen spinner.
 */
function requireDb(req, res, next) {
  if (mongoose.connection.readyState !== 1) {
    return res.status(503).json({
      error: 'The database is temporarily unavailable. Please try again in a moment.',
    });
  }
  next();
}

module.exports = { requireDb };
