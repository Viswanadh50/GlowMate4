const jwt = require('jsonwebtoken');

/**
 * Verifies the "Authorization: Bearer <token>" header on protected REST
 * routes. On success, attaches { userId, shortName } to req.user.
 */
function verifyToken(req, res, next) {
  const header = req.headers.authorization;
  if (!header || !header.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Missing or invalid authorization header.' });
  }
  const token = header.split(' ')[1];
  try {
    const payload = jwt.verify(token, process.env.JWT_SECRET);
    req.user = payload;
    next();
  } catch (err) {
    return res.status(401).json({ error: 'Invalid or expired token. Please log in again.' });
  }
}

/**
 * Same verification, but for Socket.io's handshake auth payload instead of
 * an HTTP header. Used in sockets/liveData.js so only logged-in users
 * receive live pushes and can be matched to their own reminder preferences.
 */
function verifySocketToken(socket, next) {
  const token = socket.handshake.auth?.token;
  if (!token) return next(new Error('Authentication required.'));
  try {
    socket.user = jwt.verify(token, process.env.JWT_SECRET);
    next();
  } catch (err) {
    next(new Error('Invalid or expired session. Please log in again.'));
  }
}

module.exports = { verifyToken, verifySocketToken };
