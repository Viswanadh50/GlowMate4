const mongoose = require('mongoose');
const LiveLog = require('../models/LiveLog');
const { verifySocketToken } = require('../middleware/auth');

/**
 * Scalable metric registry. To add a new live-monitored value (soil
 * moisture, room temperature, another tank, a second UV sensor at a
 * different location, etc.), add one entry here — everything downstream
 * (DB storage, socket broadcast, map markers, reminder rules) picks it up
 * automatically because it all keys off metricType.
 */
const METRICS = [
  {
    metricType: 'uv',
    label: 'UV Index',
    unit: '',
    min: 0,
    max: 11,
    location: { lat: 19.076, lng: 72.8777, label: 'Rooftop Sensor — Mumbai' },
  },
  {
    metricType: 'airQuality',
    label: 'Air Quality (AQI)',
    unit: 'AQI',
    min: 15,
    max: 180,
    location: { lat: 19.033, lng: 72.8296, label: 'Balcony Sensor — Bandra' },
  },
  {
    metricType: 'tankLevel',
    label: 'Water Tank Level',
    unit: '%',
    min: 0,
    max: 100,
    location: { lat: 19.117, lng: 72.9081, label: 'Rooftop Tank — Powai' },
  },
];

function randomWalk(previous, min, max, maxStep) {
  const base = previous == null ? (min + max) / 2 : previous;
  const next = base + (Math.random() - 0.5) * maxStep;
  return Math.round(Math.max(min, Math.min(max, next)) * 10) / 10;
}

/**
 * Wires Socket.io: authenticates each connecting client via JWT, then
 * every tick generates the next value for every metric (a smooth random
 * walk rather than pure noise, so the map/gauges feel like a real sensor
 * rather than flickering), broadcasts it to all connected clients, and
 * persists it for history/trend queries.
 */
function attachLiveDataSocket(io) {
  io.use(verifySocketToken);

  const lastValues = {}; // metricType -> last emitted value, for the random walk

  io.on('connection', (socket) => {
    console.log(`Client connected: ${socket.id} (user ${socket.user?.shortName || 'unknown'})`);

    socket.on('disconnect', () => {
      console.log(`Client disconnected: ${socket.id}`);
    });
  });

  const TICK_MS = 4000;

  setInterval(async () => {
    try {
      const snapshot = METRICS.map((m) => {
        const value = randomWalk(lastValues[m.metricType], m.min, m.max, (m.max - m.min) * 0.12);
        lastValues[m.metricType] = value;
        return {
          metricType: m.metricType,
          label: m.label,
          unit: m.unit,
          value,
          location: m.location,
          timestamp: new Date(),
        };
      });

      // The live stream must not depend on the database being up — emit
      // first, unconditionally.
      io.emit('liveData', snapshot);

      // BUG FIX: previously this always called LiveLog.insertMany even
      // while MongoDB was disconnected. Mongoose buffers queries rather
      // than rejecting them immediately, so during an outage each 4-second
      // tick queued another pending insertMany() promise on top of the
      // last one — a slow-building backlog of buffered operations that
      // only resolved (or piled up further) once the connection came back,
      // effectively a memory leak under sustained outages. Now DB writes
      // are skipped outright while disconnected; the live stream keeps
      // running, and history simply resumes once the connection recovers.
      if (mongoose.connection.readyState === 1) {
        await LiveLog.insertMany(snapshot);
      }
    } catch (err) {
      console.error('Live data tick error:', err.message);
    }
  }, TICK_MS);
}

module.exports = attachLiveDataSocket;
