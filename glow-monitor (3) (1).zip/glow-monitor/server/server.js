require('dotenv').config();
const express = require('express');
const http = require('http');
const cors = require('cors');
const mongoose = require('mongoose');
const { Server } = require('socket.io');

const authRoutes = require('./routes/auth');
const liveRoutes = require('./routes/live');
const attachLiveDataSocket = require('./sockets/liveData');

// ---- required env vars: fail loudly and immediately, not deep in a stack trace ----
if (!process.env.JWT_SECRET) {
  console.error('FATAL: JWT_SECRET is not set. Copy .env.example to .env and fill it in.');
  process.exit(1);
}
if (!process.env.MONGODB_URI) {
  console.error('FATAL: MONGODB_URI is not set. Copy .env.example to .env and fill it in.');
  process.exit(1);
}

const app = express();

/**
 * CORS origin resolution.
 * BUG FIX: cors({ origin: ['*'] }) — an array containing the string '*' —
 * does NOT mean "allow all origins". The cors package only special-cases
 * the *string* '*' passed directly; inside an array it's treated as a
 * literal value to match against, which a real browser Origin header will
 * never equal. That silently blocked every request when CLIENT_ORIGIN was
 * left unset. Fixed by passing the bare string '*' when no explicit origin
 * list is configured, and only building a whitelist array when the user
 * has actually set specific origins.
 */
const rawClientOrigin = (process.env.CLIENT_ORIGIN || '').trim();
const corsOrigin = rawClientOrigin === '' || rawClientOrigin === '*'
  ? '*'
  : rawClientOrigin.split(',').map((o) => o.trim()).filter(Boolean);

app.use(cors({ origin: corsOrigin }));
app.use(express.json());

app.get('/api/health', (req, res) => res.json({
  status: 'ok',
  time: new Date().toISOString(),
  db: mongoose.connection.readyState === 1 ? 'connected' : 'unavailable',
}));
app.use('/api/auth', authRoutes);
app.use('/api/live', liveRoutes);

// ---- 404 handler for unmatched API routes (keeps responses JSON, not Express's default HTML page) ----
app.use('/api', (req, res) => {
  res.status(404).json({ error: `No such endpoint: ${req.method} ${req.originalUrl}` });
});

// ---- centralized error-handling middleware (must have 4 args to be recognized by Express) ----
app.use((err, req, res, next) => {
  console.error('Unhandled request error:', err);
  if (res.headersSent) return next(err);
  res.status(500).json({ error: 'An unexpected server error occurred.' });
});

const server = http.createServer(app);
const io = new Server(server, {
  cors: { origin: corsOrigin },
});

attachLiveDataSocket(io);

// ---- MongoDB connection with pooling, timeouts, and automatic retry (no hard exit) ----
mongoose.set('strictQuery', true);

let mongoRetryDelayMs = 2000;
const MONGO_MAX_RETRY_DELAY_MS = 30000;

function connectMongo() {
  mongoose
    .connect(process.env.MONGODB_URI, {
      maxPoolSize: 20,
      minPoolSize: 2,
      serverSelectionTimeoutMS: 8000,
      socketTimeoutMS: 20000,
    })
    .then(() => {
      console.log('MongoDB connected.');
      mongoRetryDelayMs = 2000; // reset backoff after a successful connect
    })
    .catch((err) => {
      console.error(`MongoDB connection failed (${err.message}). Retrying in ${mongoRetryDelayMs / 1000}s.`);
      setTimeout(connectMongo, mongoRetryDelayMs);
      mongoRetryDelayMs = Math.min(mongoRetryDelayMs * 2, MONGO_MAX_RETRY_DELAY_MS);
    });
}

mongoose.connection.on('error', (err) => {
  console.error('MongoDB connection error:', err.message);
});
mongoose.connection.on('disconnected', () => {
  console.warn('MongoDB disconnected — API routes will return 503 until it reconnects.');
});
mongoose.connection.on('reconnected', () => {
  console.log('MongoDB reconnected.');
});

connectMongo();

// The HTTP/Socket.io server starts immediately and independently of MongoDB —
// health checks, auth error messages, and the live socket stream should all
// keep working (with graceful "temporarily unavailable" responses on DB-backed
// routes) even during a database outage, instead of the whole process refusing
// to boot.
const PORT = process.env.PORT || 4000;
server.listen(PORT, () => {
  console.log(`Glow Monitor server listening on port ${PORT}`);
});

// ---- process-level safety nets: log and keep running instead of crashing silently ----
process.on('unhandledRejection', (reason) => {
  console.error('Unhandled promise rejection:', reason);
});
process.on('uncaughtException', (err) => {
  console.error('Uncaught exception:', err);
});

// ---- graceful shutdown ----
function shutdown(signal) {
  console.log(`${signal} received, shutting down gracefully...`);
  server.close(() => {
    mongoose.connection.close(false).then(() => {
      console.log('Shutdown complete.');
      process.exit(0);
    });
  });
  // Force-exit if graceful shutdown hangs for too long.
  setTimeout(() => process.exit(1), 10000);
}
process.on('SIGINT', () => shutdown('SIGINT'));
process.on('SIGTERM', () => shutdown('SIGTERM'));

